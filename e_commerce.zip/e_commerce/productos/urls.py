from django.urls import path, include
from . import views

urlpatterns=[
    path("",views.home,name="home"),
    path("productos",views.product_index,name="product_index"),
    path("<int:pk>/", views.product_detail, name="product_detail"),
]