from django.shortcuts import render
from productos.models import Producto

# Create your views here.
def home(request):
    productos=Producto.objects.all()
    context={
        'productos':productos
    }
    return render(request,'home.html',context)

def product_index(request):
    productos=Producto.objects.all()
    context={
        'productos':productos
    }
    return render(request,'product_index.html',context)

def product_detail(request,pk):
    producto=Producto.objects.get(pk=pk)
    context={
        'producto':producto
    }
    return render(request,'product_detail.html',context)