from django.contrib import admin
from productos.models import Producto

# Register your models here.

class ProductoAdmin(admin.ModelAdmin):
    pass

admin.site.register(Producto,ProductoAdmin)
